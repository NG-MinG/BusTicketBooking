const PHONE_NUMBER = /^(03|05|07|08|09)\d{8}$/;

export default { PHONE_NUMBER };